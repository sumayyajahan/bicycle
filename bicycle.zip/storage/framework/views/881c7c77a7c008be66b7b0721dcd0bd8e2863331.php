<?php $__env->startSection('title'); ?>
parts
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
<div class="parts">
     <div class="container">
         <h2>BIKE-PARTS ALL</h2>
         <div class="bike-parts-sec">
              <div class="bike-parts">
                 <div class="top">
                     <ul>
                         <li><a href="<?php echo e(route('/')); ?>">home</a></li>
                         <li><a href="#"> / </a></li>
                         <li><a href="#">parts</a></li>
                     </ul>               
                 </div>
                 <div class="bike-apparels">
                     <div class="parts1">
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec">                    
                             <img src="<?php echo e(asset('/')); ?>assets/images/p1.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Wire Locks<span>$7.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec">                    
                             <img src="<?php echo e(asset('/')); ?>assets/images/p3.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Gloves<span>$50.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec none1">                  
                             <img src="<?php echo e(asset('/')); ?>assets/images/p2.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Speed Cassette<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="single.html">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec none1">                  
                             <img src="<?php echo e(asset('/')); ?>assets/images/p4.JPG" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Road Bike Pedals<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <div class="clearfix"></div>
                     </div>
                     
                     <div class="parts2">
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec">                    
                             <img src="<?php echo e(asset('/')); ?>assets/images/p5.JPG" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Rear Derailleur<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec">                    
                             <img src="<?php echo e(asset('/')); ?>assets/images/p6.JPG" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Race XC Crankset<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec none1">                  
                             <img src="<?php echo e(asset('/')); ?>assets/images/p7.JPG" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Aero Handlebars<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec none1">                  
                             <img src="<?php echo e(asset('/')); ?>assets/images/p8.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Grip Tires<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="single.html">BUY NOW</a>
                             </div>
                         </div></a>
                         <div class="clearfix"></div>
                     </div>
                     
                     <div class="parts3">
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec">                    
                             <img src="<?php echo e(asset('/')); ?>assets/images/p9.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Bike Wheelset<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec">                    
                             <img src="<?php echo e(asset('/')); ?>assets/images/p10.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>MTB Chainring<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec none1">                  
                             <img src="<?php echo e(asset('/')); ?>assets/images/p11.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Suspensions<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec none1">                  
                             <img src="<?php echo e(asset('/')); ?>assets/images/p12.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Helmets<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <div class="clearfix"></div>
                     </div>
                     
                     <div class="parts4">
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec bottom-line">                    
                             <img src="<?php echo e(asset('/')); ?>assets/images/p13.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Middle Frames<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec bottom-line">                    
                             <img src="<?php echo e(asset('/')); ?>assets/images/p14.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Brooks Saddle<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec bottom-line none1">                  
                             <img src="<?php echo e(asset('/')); ?>assets/images/p15.jpg" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Motocross braces<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <a href="<?php echo e(route('single')); ?>"><div class="part-sec none1">                  
                             <img src="<?php echo e(asset('/')); ?>assets/images/p16.JPG" alt=""/>
                             <div class="part-info">
                                 <a href="#"><h5>Bike Pumps<span>$200.00</span></h5></a>
                                 <a class="add-cart" href="<?php echo e(route('single')); ?>">Quick View</a>
                                 <a class="qck" href="<?php echo e(route('single')); ?>">BUY NOW</a>
                             </div>
                         </div></a>
                         <div class="clearfix"></div>
                     </div>
                     
                 </div>
             </div>
             <div class="rsidebar span_1_of_left">
                 <section  class="sky-form">
                     <div class="product_right">
                         <h3 class="m_2">Categories</h3>
                            <select class="dropdown" tabindex="10" data-settings='{"wrapperClass":"metro"}'>
                                <option value="0">Frames</option>   
                                <option value="1">Back Packs</option>
                                <option value="2">Frame Bags</option>
                                <option value="3">Panniers </option>
                                <option value="4">Saddle Bags</option>                              
                           </select>
                           <select class="dropdown" tabindex="50" data-settings='{"wrapperClass":"metro"}'>
                                <option value="1">Body Armour</option>
                                <option value="2">Sub Category1</option>
                                <option value="3">Sub Category2</option>
                                <option value="4">Sub Category3</option>
                           </select>
                           <select class="dropdown" tabindex="8" data-settings='{"wrapperClass":"metro"}'>
                                <option value="1">Tools</option>
                                <option value="2">Sub Category1</option>
                                <option value="3">Sub Category2</option>
                                <option value="4">Sub Category3</option>
                           </select>
                           <select class="dropdown" tabindex="8" data-settings='{"wrapperClass":"metro"}'>
                                <option value="1">Services</option>
                                <option value="2">Sub Category1</option>
                                <option value="3">Sub Category2</option>
                                <option value="4">Sub Category3</option>
                           </select>
                           <select class="dropdown" tabindex="8" data-settings='{"wrapperClass":"metro"}'>
                                <option value="1">Materials</option>
                                <option value="2">Sub Category1</option>
                                <option value="3">Sub Category2</option>
                                <option value="4">Sub Category3</option>
                           </select>
                      </div>
             
                     <h4>components</h4>
                     <div class="row row1 scroll-pane">
                         <div class="col col-4">
                                <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>Frames(20)</label>
                         </div>
                         <div class="col col-4">
                                <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Foks, Suspensions (48)</label>
                                <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Breaks and Pedals (45)</label>
                                <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Tires,Tubes,Wheels (45)</label>
                                <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Serevice Parts(12)</label>
                         </div>
                     </div>
                     <h4>Apparels</h4>
                     <div class="row row1 scroll-pane">
                         <div class="col col-4">
                                <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>Locks (20)</label>
                         </div>
                         <div class="col col-4">
                                <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Speed Cassette (5)</label>
                                <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Bike Pedals (7)</label>
                                <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Handels (2)</label>
                                <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Other (50)</label>
                         </div>
                     </div>
                 </section>
                 <section  class="sky-form">
                        <h4>Brand</h4>
                            <div class="row row1 scroll-pane">
                                <div class="col col-4">
                                    <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>Lezyne</label>
                                </div>
                                <div class="col col-4">
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Marzocchi</label>
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>EBC</label>
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Oakley</label>
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Jagwire</label>
                                    <label class="checkbox"><input type="checkbox" name="checkbox" ><i></i>Yeti Cycles</label>
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Vee Rubber</label>
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Zumba</label>
                                </div>
                            </div>
                   </section>             
                   <section  class="sky-form">
                        <h4>Price</h4>
                            <div class="row row1 scroll-pane">
                                <div class="col col-4">
                                    <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>$50.00 and Under (30)</label>
                                </div>
                                <div class="col col-4">
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>$100.00 and Under (30)</label>
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>$200.00 and Under (30)</label>
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>$300.00 and Under (30)</label>
                                    <label class="checkbox"><input type="checkbox" name="checkbox"><i></i>$400.00 and Under (30)</label>
                                </div>
                            </div>
                   </section>              
             </div>          
             <div class="clearfix"></div>
         </div>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>