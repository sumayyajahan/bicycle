<div class="banner-bg banner-sec">  
      <div class="container">
             <div class="header">
                   <div class="logo">
                         <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('/')); ?>assets/images/logo.png" alt=""/></a>
                   </div>                            
                  <div class="top-nav">                                      
                        <label class="mobile_menu" for="mobile_menu">
                        <span>Menu</span>
                        </label>
                        <input id="mobile_menu" type="checkbox">
                       <ul class="nav">
                          <li class="dropdown1"><a href="<?php echo e(route('bicycles')); ?>">BICYCLES</a>
                              <ul class="dropdown2">
                                    <li><a href="<?php echo e(route('bicycles')); ?>">FIXED / SINGLE SPEED</a></li>
                                    <li><a href="<?php echo e(route('bicycles')); ?>">CITY BIKES</a></li>
                                    <li><a href="<?php echo e(route('bicycles')); ?>">PREMIMUN SERIES</a></li>                                              
                              </ul>
                          </li>
                          <li class="dropdown1"><a href="<?php echo e(route('parts')); ?>">PARTS</a>
                             <ul class="dropdown2">
                                    <li><a href="<?php echo e(route('parts')); ?>">CHAINS</a></li>
                                    <li><a href="<?php echo e(route('parts')); ?>">TUBES</a></li>
                                    <li><a href="<?php echo e(route('parts')); ?>">TIRES</a></li>
                                    <li><a href="<?php echo e(route('parts')); ?>">DISC BREAKS</a></li>
                              </ul>
                         </li>      
                         <li class="dropdown1"><a href="<?php echo e(route('accessories')); ?>">ACCESSORIES</a>
                             <ul class="dropdown2">
                                    <li><a href="<?php echo e(route('accessories')); ?>">LOCKS</a></li>
                                        <li><a href="<?php echo e(route('accessories')); ?>">HELMETS</a></li>
                                        <li><a href="<?php echo e(route('accessories')); ?>">ARM COVERS</a></li>
                                        <li><a href="<?php echo e(route('accessories')); ?>">JERSEYS</a></li>
                              </ul>
                         </li>               
                         <li class="dropdown1"><a href="<?php echo e(route('accessories')); ?>">EXTRAS</a>
                             <ul class="dropdown2">
                                    <li><a href="<?php echo e(route('accessories')); ?>">CLASSIC BELL</a></li>
                                    <li><a href="<?php echo e(route('accessories')); ?>">BOTTLE CAGE</a></li>
                                    <li><a href="<?php echo e(route('accessories')); ?>">TRUCK GRIP</a></li>
                              </ul>
                         </li>
                          <a class="shop" href="<?php echo e(route('cart')); ?>"><img src="<?php echo e(asset('/')); ?>assets/images/cart.png" alt=""/></a>
                      </ul>
                 </div>
                 <div class="clearfix"></div>
             </div>
      </div>                 
</div>