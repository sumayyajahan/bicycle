<div class="footer">
     <div class="container wrap">
        <div class="logo2">
             <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('/')); ?>assets/images/logo2.png" alt=""/></a>
        </div>
        <div class="ftr-menu">
             <ul>
                 <li><a href="<?php echo e(route('bicycles')); ?>">BICYCLES</a></li>
                 <li><a href="<?php echo e(route('parts')); ?>">PARTS</a></li>
                 <li><a href="<?php echo e(route('accessories')); ?>">ACCESSORIES</a></li>
                 <li><a href="<?php echo e(route('accessories')); ?>">EXTRAS</a></li>
             </ul>
        </div>
        <div class="clearfix"></div>
     </div>
</div>