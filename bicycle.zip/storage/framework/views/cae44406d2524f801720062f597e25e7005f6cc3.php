<script src="<?php echo e(asset('/')); ?>assets/js/responsiveslides.min.js"></script>
<script>  
    $(function () {
      $("#slider").responsiveSlides({
        auto: true,
        nav: true,
        speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script>
<div class="banner-bg banner-bg1">  
      <div class="container">
             <div class="header">
                   <div class="logo">
                         <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('/')); ?>assets/images/logo.png" alt=""/></a>
                   </div>                            
                  <div class="top-nav">                                      
                        <label class="mobile_menu" for="mobile_menu">
                        <span>Menu</span>
                        </label>
                        <input id="mobile_menu" type="checkbox">
                       <ul class="nav">
                          <li class="dropdown1"><a href="<?php echo e(route('bicycles')); ?>">BICYCLES</a>
                              <ul class="dropdown2">
                                    <li><a href="<?php echo e(route('bicycles')); ?>">FIXED / SINGLE SPEED</a></li>
                                    <li><a href="<?php echo e(route('bicycles')); ?>">CITY BIKES</a></li>
                                    <li><a href="<?php echo e(route('bicycles')); ?>">PREMIMUN SERIES</a></li>                                                
                              </ul>
                          </li>
                          <li class="dropdown1"><a href="<?php echo e(route('parts')); ?>">PARTS</a>
                             <ul class="dropdown2">
                                    <li><a href="<?php echo e(route('parts')); ?>">CHAINS</a></li>
                                    <li><a href="<?php echo e(route('parts')); ?>">TUBES</a></li>
                                    <li><a href="<?php echo e(route('parts')); ?>">TIRES</a></li>
                                    <li><a href="<?php echo e(route('parts')); ?>">DISC BREAKS</a></li>
                              </ul>
                         </li>      
                         <li class="dropdown1"><a href="<?php echo e(route('accessories')); ?>">ACCESSORIES</a>
                             <ul class="dropdown2">
                                    <li><a href="<?php echo e(route('accessories')); ?>">LOCKS</a></li>
                                        <li><a href="<?php echo e(route('accessories')); ?>">HELMETS</a></li>
                                        <li><a href="<?php echo e(route('accessories')); ?>">ARM COVERS</a></li>
                                        <li><a href="<?php echo e(route('accessories')); ?>">JERSEYS</a></li>
                              </ul>
                         </li>               
                         <li class="dropdown1"><a href="<?php echo e(route('accessories')); ?>">EXTRAS</a>
                             <ul class="dropdown2">
                                    <li><a href="<?php echo e(route('accessories')); ?>">CLASSIC BELL</a></li>
                                    <li><a href="<?php echo e(route('accessories')); ?>">BOTTLE CAGE</a></li>
                                    <li><a href="<?php echo e(route('accessories')); ?>">TRUCK GRIP</a></li>
                              </ul>
                         </li>
                          <a class="shop" href="<?php echo e(route('cart')); ?>"><img src="<?php echo e(asset('/')); ?>assets/images/cart.png" alt=""/></a>
                      </ul>
                 </div>
                 <div class="clearfix"></div>
             </div>
      </div>     
     <div class="caption">
         <div class="slider">
                       <div class="callbacks_container">
                           <ul class="rslides" id="slider">
                                <li><h1>HANDMADE BICYCLE</h1></li>
                                <li><h1>SPEED BICYCLE</h1></li> 
                                <li><h1>MOUINTAIN BICYCLE</h1></li> 
                          </ul>
                          <p>You <span>create</span> the <span>journey,</span> we supply the <span>parts</span></p>
                          <a class="morebtn" href="<?php echo e(route('bicycles')); ?>">SHOP BIKES</a>
                      </div>
                  </div>
     </div>
     <div class="dwn">
        <a class="scroll" href="#cate"><img src="<?php echo e(asset('/')); ?>assets/images/scroll.png" alt=""/></a>
     </div>              
</div>