<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [
   'uses' => 'BicycleController@index',
    'as' => '/'
	]);

Route::get('/bicycles', [
    'uses' => 'BicycleController@bicycles',
     'as' => 'bicycles'
	]);

Route::get('/parts', [
    'uses' => 'BicycleController@parts',
     'as' => 'parts'
	]);

Route::get('/accessories', [
    'uses' => 'BicycleController@accessories',
     'as' => 'accessories'
	]);

Route::get('/cart', [
    'uses' => 'BicycleController@cart',
     'as' => 'cart'
	]); 

Route::get('/single', [
    'uses' => 'BicycleController@single',
     'as' => 'single'
    ]);

Route::get('/category',[
    'uses' => 'CategoryController@index',
    'as' => 'add-category'
    ]); 

Route::get('/subcategory',[
    'uses' => 'CategoryController@manage',
    'as' => 'manage-subcategory'
    ]);


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
