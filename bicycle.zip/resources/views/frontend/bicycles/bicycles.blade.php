@extends('frontend.master')

@section('title')
bicycles
@endsection


@section('body')
<div class="bikes">      
     <div class="mountain-sec">
         <h2>MOUNTAIN BIKES</h2>
         <a href="single.html"><div class="bike">                
             <img src="{{ asset('/') }}assets/images/bik3.jpg" alt=""/>
             <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <a href="single.html"><div class="bike">                
                 <img src="{{ asset('/') }}assets/images/bik1.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <a href="single.html"><div class="bike none2">              
                 <img src="{{ asset('/') }}assets/images/bik4.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <a href="single.html"><div class="bike none1">              
                 <img src="{{ asset('/') }}assets/images/bik6.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <div class="clearfix"></div>
      </div>
         
      <div class="singlespeed-sec">
           <h2>SINGLE SPEED-BIKES</h2>
             <a href="single.html"><div class="bike">                
                 <img src="{{ asset('/') }}assets/images/s1.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <a href="single.html"><div class="bike">                
                 <img src="{{ asset('/') }}assets/images/s2.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <a href="single.html"><div class="bike none2">              
                 <img src="{{ asset('/') }}assets/images/s3.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <a href="single.html"><div class="bike none1">              
                 <img src="{{ asset('/') }}assets/images/s4.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <div class="clearfix"></div>
         </div>
         
         <div class="road-sec">
           <h2>ROAD-BIKES</h2>
             <a href="single.html"><div class="bike">                
                 <img src="{{ asset('/') }}assets/images/r1.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <a href="single.html"><div class="bike">                
                 <img src="{{ asset('/') }}assets/images/r3.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <a href="single.html"><div class="bike none2">              
                 <img src="{{ asset('/') }}assets/images/r2.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <a href="single.html"><div class="bike none1">              
                 <img src="{{ asset('/') }}assets/images/r4.jpg" alt=""/>
                 <div class="bike-cost">
                     <div class="bike-mdl">
                         <h4>NAME<span>Model:M4585</span></h4>
                     </div>
                     <div class="bike-cart">                         
                         <a class="buy" href="single.html">BUY NOW</a>
                     </div>
                     <div class="clearfix"></div>
                 </div>
                 <div class="fast-viw">
                        <a href="single.html">Quick View</a>
                 </div>
             </div></a>
             <div class="clearfix"></div>
         </div>
         
     </div>
@endsection