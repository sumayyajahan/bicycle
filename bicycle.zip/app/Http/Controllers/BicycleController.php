<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BicycleController extends Controller
{
    public function index()
    {
    	return view('frontend.home.home');
    }

    public function bicycles()
    {
    	return view('frontend.bicycles.bicycles');
    }

    public function parts()
    {
    	return view('frontend.parts.parts');
    }

    public function accessories()
    {
    	return view('frontend.accessories.accessories');
    }

    public function cart()
    {
        return view('frontend.cart.cart');
    }

    public function single()
    {
        return view('frontend.single.single');
    }
}
